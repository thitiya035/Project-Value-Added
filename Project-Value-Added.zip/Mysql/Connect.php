
<?php

require 'Config.php';
$dbcon = mysqli_connect($servername,$username,$password,$dbname);
mysqli_set_charset($dbcon,"utf8");


?>