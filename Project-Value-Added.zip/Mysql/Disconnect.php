<?php

    mysqli_close($dbcon);

?>