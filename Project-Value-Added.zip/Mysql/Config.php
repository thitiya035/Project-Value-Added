<?php

$username = "root";
$password = "";
$servername = "localhost";
$dbname = "projectbc";

?>